--
-- PostgreSQL database dump
--

\restrict DeWnVN22ph54nweoUo1D1VlSjG6lJfZsuYbG1AIuz8SS7OLcN5Kxq7kvB0VF7lI

-- Dumped from database version 15.18
-- Dumped by pg_dump version 15.18

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: library
--

-- *not* creating schema, since initdb creates it


ALTER SCHEMA public OWNER TO library;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: library
--

COMMENT ON SCHEMA public IS '';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: ai_corrections; Type: TABLE; Schema: public; Owner: library
--

CREATE TABLE public.ai_corrections (
    id uuid NOT NULL,
    owner_id uuid NOT NULL,
    import_item_id uuid,
    digest_hash character varying(64),
    proposal jsonb DEFAULT '{}'::jsonb NOT NULL,
    applied jsonb NOT NULL,
    source character varying(16) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.ai_corrections OWNER TO library;

--
-- Name: ai_proposals; Type: TABLE; Schema: public; Owner: library
--

CREATE TABLE public.ai_proposals (
    id uuid NOT NULL,
    digest_hash character varying(64) NOT NULL,
    model character varying(128) NOT NULL,
    prompt_version integer NOT NULL,
    schema_version integer NOT NULL,
    proposal jsonb NOT NULL,
    raw_response text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.ai_proposals OWNER TO library;

--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: library
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


ALTER TABLE public.alembic_version OWNER TO library;

--
-- Name: api_tokens; Type: TABLE; Schema: public; Owner: library
--

CREATE TABLE public.api_tokens (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    token_type character varying(16) NOT NULL,
    token_hash character varying(64) NOT NULL,
    scopes text DEFAULT ''::text NOT NULL,
    name text,
    expires_at timestamp with time zone,
    revoked_at timestamp with time zone,
    last_used_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.api_tokens OWNER TO library;

--
-- Name: asset_relations; Type: TABLE; Schema: public; Owner: library
--

CREATE TABLE public.asset_relations (
    id uuid NOT NULL,
    owner_id uuid NOT NULL,
    asset_id uuid NOT NULL,
    related_asset_id uuid NOT NULL,
    relation_type character varying(16) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_asset_relations_distinct CHECK ((asset_id <> related_asset_id))
);


ALTER TABLE public.asset_relations OWNER TO library;

--
-- Name: assets; Type: TABLE; Schema: public; Owner: library
--

CREATE TABLE public.assets (
    id uuid NOT NULL,
    owner_id uuid NOT NULL,
    sha256 character varying(64) NOT NULL,
    format character varying(16) NOT NULL,
    kind character varying(16) NOT NULL,
    size_bytes integer NOT NULL,
    storage_path text NOT NULL,
    original_filename text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    work_id uuid,
    is_preferred boolean DEFAULT false NOT NULL,
    CONSTRAINT ck_assets_size_nonnegative CHECK ((size_bytes >= 0))
);


ALTER TABLE public.assets OWNER TO library;

--
-- Name: audit_log; Type: TABLE; Schema: public; Owner: library
--

CREATE TABLE public.audit_log (
    id uuid NOT NULL,
    user_id uuid,
    action character varying(64) NOT NULL,
    entity_type character varying(64),
    entity_id text,
    actor_ip character varying(64),
    details jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.audit_log OWNER TO library;

--
-- Name: author_aliases; Type: TABLE; Schema: public; Owner: library
--

CREATE TABLE public.author_aliases (
    id uuid NOT NULL,
    owner_id uuid NOT NULL,
    author_id uuid NOT NULL,
    alias text NOT NULL,
    alias_normalized text NOT NULL
);


ALTER TABLE public.author_aliases OWNER TO library;

--
-- Name: authors; Type: TABLE; Schema: public; Owner: library
--

CREATE TABLE public.authors (
    id uuid NOT NULL,
    owner_id uuid NOT NULL,
    name text NOT NULL,
    name_normalized text NOT NULL,
    sort_name text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.authors OWNER TO library;

--
-- Name: duplicate_candidates; Type: TABLE; Schema: public; Owner: library
--

CREATE TABLE public.duplicate_candidates (
    id uuid NOT NULL,
    owner_id uuid NOT NULL,
    asset_id uuid NOT NULL,
    suspected_of_asset_id uuid NOT NULL,
    reason character varying(32) NOT NULL,
    status character varying(24) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.duplicate_candidates OWNER TO library;

--
-- Name: import_batches; Type: TABLE; Schema: public; Owner: library
--

CREATE TABLE public.import_batches (
    id uuid NOT NULL,
    owner_id uuid NOT NULL,
    source character varying(16) NOT NULL,
    status character varying(16) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    completed_at timestamp with time zone
);


ALTER TABLE public.import_batches OWNER TO library;

--
-- Name: import_items; Type: TABLE; Schema: public; Owner: library
--

CREATE TABLE public.import_items (
    id uuid NOT NULL,
    batch_id uuid NOT NULL,
    owner_id uuid NOT NULL,
    filename text NOT NULL,
    status character varying(24) NOT NULL,
    size_bytes integer,
    sha256 character varying(64),
    detected_format character varying(8),
    asset_id uuid,
    work_id uuid,
    match_evidence jsonb DEFAULT '{}'::jsonb NOT NULL,
    error text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.import_items OWNER TO library;

--
-- Name: jobs; Type: TABLE; Schema: public; Owner: library
--

CREATE TABLE public.jobs (
    id uuid NOT NULL,
    kind character varying(64) NOT NULL,
    payload jsonb DEFAULT '{}'::jsonb NOT NULL,
    status character varying(16) DEFAULT 'queued'::character varying NOT NULL,
    run_at timestamp with time zone DEFAULT now() NOT NULL,
    attempts integer DEFAULT 0 NOT NULL,
    max_attempts integer DEFAULT 5 NOT NULL,
    last_error text,
    locked_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.jobs OWNER TO library;

--
-- Name: normalization_runs; Type: TABLE; Schema: public; Owner: library
--

CREATE TABLE public.normalization_runs (
    id uuid NOT NULL,
    owner_id uuid NOT NULL,
    input_asset_id uuid NOT NULL,
    derivative_asset_id uuid,
    input_sha256 character varying(64),
    output_sha256 character varying(64),
    profile character varying(32) NOT NULL,
    profile_version integer NOT NULL,
    normalizer_version character varying(32) NOT NULL,
    state character varying(24) NOT NULL,
    needs_review boolean NOT NULL,
    review_reason text,
    actions jsonb DEFAULT '[]'::jsonb NOT NULL,
    manifest jsonb DEFAULT '{}'::jsonb NOT NULL,
    error text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    completed_at timestamp with time zone
);


ALTER TABLE public.normalization_runs OWNER TO library;

--
-- Name: notifications; Type: TABLE; Schema: public; Owner: library
--

CREATE TABLE public.notifications (
    id uuid NOT NULL,
    owner_id uuid NOT NULL,
    kind character varying(32) NOT NULL,
    title text NOT NULL,
    body text DEFAULT ''::text NOT NULL,
    data jsonb DEFAULT '{}'::jsonb NOT NULL,
    read_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.notifications OWNER TO library;

--
-- Name: outbox_events; Type: TABLE; Schema: public; Owner: library
--

CREATE TABLE public.outbox_events (
    id uuid NOT NULL,
    event_type character varying(64) NOT NULL,
    payload jsonb DEFAULT '{}'::jsonb NOT NULL,
    status character varying(16) DEFAULT 'pending'::character varying NOT NULL,
    attempts integer DEFAULT 0 NOT NULL,
    last_error text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    processed_at timestamp with time zone
);


ALTER TABLE public.outbox_events OWNER TO library;

--
-- Name: reading_state_history; Type: TABLE; Schema: public; Owner: library
--

CREATE TABLE public.reading_state_history (
    id uuid NOT NULL,
    owner_id uuid NOT NULL,
    work_id uuid NOT NULL,
    from_status character varying(16),
    to_status character varying(16) NOT NULL,
    source character varying(16) NOT NULL,
    changed_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.reading_state_history OWNER TO library;

--
-- Name: reading_states; Type: TABLE; Schema: public; Owner: library
--

CREATE TABLE public.reading_states (
    id uuid NOT NULL,
    owner_id uuid NOT NULL,
    work_id uuid NOT NULL,
    status character varying(16) NOT NULL,
    progress_percent integer,
    change_source character varying(16) NOT NULL,
    changed_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_reading_states_progress_range CHECK (((progress_percent IS NULL) OR ((progress_percent >= 0) AND (progress_percent <= 100))))
);


ALTER TABLE public.reading_states OWNER TO library;

--
-- Name: series; Type: TABLE; Schema: public; Owner: library
--

CREATE TABLE public.series (
    id uuid NOT NULL,
    owner_id uuid NOT NULL,
    title text NOT NULL,
    title_normalized text NOT NULL,
    description text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.series OWNER TO library;

--
-- Name: series_aliases; Type: TABLE; Schema: public; Owner: library
--

CREATE TABLE public.series_aliases (
    id uuid NOT NULL,
    owner_id uuid NOT NULL,
    series_id uuid NOT NULL,
    alias text NOT NULL,
    alias_normalized text NOT NULL
);


ALTER TABLE public.series_aliases OWNER TO library;

--
-- Name: series_memberships; Type: TABLE; Schema: public; Owner: library
--

CREATE TABLE public.series_memberships (
    id uuid NOT NULL,
    owner_id uuid NOT NULL,
    series_id uuid NOT NULL,
    work_id uuid NOT NULL,
    index_raw text NOT NULL,
    index_sort numeric(12,4),
    membership_type character varying(16) NOT NULL
);


ALTER TABLE public.series_memberships OWNER TO library;

--
-- Name: series_user_states; Type: TABLE; Schema: public; Owner: library
--

CREATE TABLE public.series_user_states (
    id uuid NOT NULL,
    owner_id uuid NOT NULL,
    series_id uuid NOT NULL,
    status_override character varying(24) NOT NULL,
    note text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.series_user_states OWNER TO library;

--
-- Name: source_author_records; Type: TABLE; Schema: public; Owner: library
--

CREATE TABLE public.source_author_records (
    id uuid NOT NULL,
    owner_id uuid NOT NULL,
    adapter_id character varying(64) NOT NULL,
    external_id text NOT NULL,
    author_id uuid,
    url text,
    raw_metadata jsonb NOT NULL,
    last_observed_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.source_author_records OWNER TO library;

--
-- Name: source_observations; Type: TABLE; Schema: public; Owner: library
--

CREATE TABLE public.source_observations (
    id uuid NOT NULL,
    owner_id uuid NOT NULL,
    watch_rule_id uuid NOT NULL,
    adapter_id character varying(32) NOT NULL,
    external_id text NOT NULL,
    title text NOT NULL,
    author_name text,
    url text,
    parser_version character varying(32) NOT NULL,
    raw jsonb DEFAULT '{}'::jsonb NOT NULL,
    observed_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.source_observations OWNER TO library;

--
-- Name: source_records; Type: TABLE; Schema: public; Owner: library
--

CREATE TABLE public.source_records (
    id uuid NOT NULL,
    owner_id uuid NOT NULL,
    adapter_id character varying(64) NOT NULL,
    external_id text NOT NULL,
    work_id uuid,
    url text,
    raw_metadata jsonb NOT NULL,
    parser_version character varying(32),
    last_observed_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.source_records OWNER TO library;

--
-- Name: users; Type: TABLE; Schema: public; Owner: library
--

CREATE TABLE public.users (
    id uuid NOT NULL,
    email text NOT NULL,
    password_hash text NOT NULL,
    display_name text,
    is_active boolean DEFAULT true NOT NULL,
    is_superuser boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.users OWNER TO library;

--
-- Name: watch_rules; Type: TABLE; Schema: public; Owner: library
--

CREATE TABLE public.watch_rules (
    id uuid NOT NULL,
    owner_id uuid NOT NULL,
    adapter_id character varying(32) NOT NULL,
    name text NOT NULL,
    url text NOT NULL,
    interval_seconds integer DEFAULT 3600 NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    etag text,
    last_modified text,
    last_polled_at timestamp with time zone,
    next_poll_at timestamp with time zone,
    failure_count integer DEFAULT 0 NOT NULL,
    degraded boolean DEFAULT false NOT NULL,
    last_error text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.watch_rules OWNER TO library;

--
-- Name: work_authors; Type: TABLE; Schema: public; Owner: library
--

CREATE TABLE public.work_authors (
    id uuid NOT NULL,
    owner_id uuid NOT NULL,
    work_id uuid NOT NULL,
    author_id uuid NOT NULL,
    role character varying(16) NOT NULL,
    "position" integer NOT NULL
);


ALTER TABLE public.work_authors OWNER TO library;

--
-- Name: works; Type: TABLE; Schema: public; Owner: library
--

CREATE TABLE public.works (
    id uuid NOT NULL,
    owner_id uuid NOT NULL,
    title text NOT NULL,
    title_normalized text NOT NULL,
    language character varying(16),
    description text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.works OWNER TO library;

--
-- Data for Name: ai_corrections; Type: TABLE DATA; Schema: public; Owner: library
--

COPY public.ai_corrections (id, owner_id, import_item_id, digest_hash, proposal, applied, source, created_at) FROM stdin;
\.


--
-- Data for Name: ai_proposals; Type: TABLE DATA; Schema: public; Owner: library
--

COPY public.ai_proposals (id, digest_hash, model, prompt_version, schema_version, proposal, raw_response, created_at) FROM stdin;
2d1200a6-9fa5-460c-834d-daf771f5aa0a	0eead9f86dada36c6f46258b3fa0ca716882ab06664f6dd3c8cba76286031078	auto/best-free	1	1	{"title": "Соболева Л А Артель Света 3824 1", "author": null, "series": null, "confidence": 0.35, "ambiguities": ["Вероятно, что подстрока 'Соболева Л А' является автором, но это не подтверждено parsed_filename.author.", "Фрагменты 'Артель Света 3824 1' могут быть частью серии/номера или названием, но разделение не выполнено.", "parsed_filename.well_formed=false указывает на некорректную структуру имени файла."], "field_evidence": {"title": "Использовано значение parsed_filename.title, т.к. иных данных о названии нет.", "author": "В parsed_filename.author указано null; имя автора в title распознано неотделимо от остального текста."}, "requires_review": true, "series_index_raw": null, "match_existing_work_id": null}	{\n  "author": null,\n  "title": "Соболева Л А Артель Света 3824 1",\n  "series": null,\n  "series_index_raw": null,\n  "match_existing_work_id": null,\n  "confidence": 0.35,\n  "requires_review": true,\n  "field_evidence": {\n    "author": "В parsed_filename.author указано null; имя автора в title распознано неотделимо от остального текста.",\n    "title": "Использовано значение parsed_filename.title, т.к. иных данных о названии нет."\n  },\n  "ambiguities": [\n    "Вероятно, что подстрока 'Соболева Л А' является автором, но это не подтверждено parsed_filename.author.",\n    "Фрагменты 'Артель Света 3824 1' могут быть частью серии/номера или названием, но разделение не выполнено.",\n    "parsed_filename.well_formed=false указывает на некорректную структуру имени файла."\n  ]\n}	2026-08-26 08:52:01.035587+00
\.


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: library
--

COPY public.alembic_version (version_num) FROM stdin;
0007
\.


--
-- Data for Name: api_tokens; Type: TABLE DATA; Schema: public; Owner: library
--

COPY public.api_tokens (id, user_id, token_type, token_hash, scopes, name, expires_at, revoked_at, last_used_at, created_at) FROM stdin;
1a00a896-85db-46ed-86ac-bde43dbf50cb	68ace0b5-3f85-4d88-8460-65ad4bee6826	refresh	dc1c3bb2bff0073336e839c277c90c017f9136e97e8e09a26a9a6476098a20db	portal:full	\N	2026-09-25 08:51:30.412023+00	\N	\N	2026-08-26 08:51:30.412178+00
\.


--
-- Data for Name: asset_relations; Type: TABLE DATA; Schema: public; Owner: library
--

COPY public.asset_relations (id, owner_id, asset_id, related_asset_id, relation_type, created_at) FROM stdin;
\.


--
-- Data for Name: assets; Type: TABLE DATA; Schema: public; Owner: library
--

COPY public.assets (id, owner_id, sha256, format, kind, size_bytes, storage_path, original_filename, created_at, work_id, is_preferred) FROM stdin;
71188d34-fa3b-4a66-b5eb-8c573960ca00	68ace0b5-3f85-4d88-8460-65ad4bee6826	a4fc1bf65de39445acef952031909765db82e2926e446bfedb6fc1cffe1bab63	fb2	original	149	originals/a4/a4fc1bf65de39445acef952031909765db82e2926e446bfedb6fc1cffe1bab63.fb2	Соболева_Л_А_Артель_Света_3824_1.fb2	2026-08-26 08:51:30.749854+00	\N	f
\.


--
-- Data for Name: audit_log; Type: TABLE DATA; Schema: public; Owner: library
--

COPY public.audit_log (id, user_id, action, entity_type, entity_id, actor_ip, details, created_at) FROM stdin;
5dbedad7-4fcc-49d0-b587-2eb0af9f2763	68ace0b5-3f85-4d88-8460-65ad4bee6826	register	\N	\N	127.0.0.1	{"bootstrap": true}	2026-08-26 08:51:29.599888+00
1bfeca14-c465-406a-9bed-730dfb113f4f	68ace0b5-3f85-4d88-8460-65ad4bee6826	login	\N	\N	127.0.0.1	{}	2026-08-26 08:51:30.088061+00
\.


--
-- Data for Name: author_aliases; Type: TABLE DATA; Schema: public; Owner: library
--

COPY public.author_aliases (id, owner_id, author_id, alias, alias_normalized) FROM stdin;
\.


--
-- Data for Name: authors; Type: TABLE DATA; Schema: public; Owner: library
--

COPY public.authors (id, owner_id, name, name_normalized, sort_name, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: duplicate_candidates; Type: TABLE DATA; Schema: public; Owner: library
--

COPY public.duplicate_candidates (id, owner_id, asset_id, suspected_of_asset_id, reason, status, created_at) FROM stdin;
\.


--
-- Data for Name: import_batches; Type: TABLE DATA; Schema: public; Owner: library
--

COPY public.import_batches (id, owner_id, source, status, created_at, completed_at) FROM stdin;
50d72b13-7d51-476b-b30f-7203a05ca86d	68ace0b5-3f85-4d88-8460-65ad4bee6826	upload	completed	2026-08-26 08:51:30.562265+00	2026-08-26 08:51:30.879875+00
\.


--
-- Data for Name: import_items; Type: TABLE DATA; Schema: public; Owner: library
--

COPY public.import_items (id, batch_id, owner_id, filename, status, size_bytes, sha256, detected_format, asset_id, work_id, match_evidence, error, created_at) FROM stdin;
e8b884c6-30ba-4c0b-ab7e-c5238cd1de32	50d72b13-7d51-476b-b30f-7203a05ca86d	68ace0b5-3f85-4d88-8460-65ad4bee6826	Соболева_Л_А_Артель_Света_3824_1.fb2	stored_unmatched	149	a4fc1bf65de39445acef952031909765db82e2926e446bfedb6fc1cffe1bab63	fb2	71188d34-fa3b-4a66-b5eb-8c573960ca00	\N	{"parsed": {"title": "Соболева Л А Артель Света 3824 1", "author": null, "series": null, "series_index": null}, "parser": "deterministic-v1"}	\N	2026-08-26 08:51:30.69845+00
\.


--
-- Data for Name: jobs; Type: TABLE DATA; Schema: public; Owner: library
--

COPY public.jobs (id, kind, payload, status, run_at, attempts, max_attempts, last_error, locked_at, created_at, updated_at) FROM stdin;
7892ad59-a7f5-4f09-ae29-87a9fbd5f9bb	normalize	{"run_id": "9ca2038a-4565-4ca0-bdac-07cd9a07c5a8", "owner_id": "d068a75e-f341-4daa-9243-168a011d616f"}	failed	2026-08-25 10:18:51.933533+00	5	5	Foreign key associated with column 'assets.owner_id' could not find table 'users' with which to generate a foreign key to target column 'id'	\N	2026-08-25 10:18:51.867861+00	2026-08-25 10:18:53.630039+00
846229f2-999d-4280-bb7b-769de8c4cf38	normalize	{"run_id": "6f204057-d25e-4890-a264-68d22a5d201b", "owner_id": "d068a75e-f341-4daa-9243-168a011d616f"}	done	2026-08-25 10:23:10.812731+00	0	5	\N	\N	2026-08-25 10:23:10.782884+00	2026-08-25 10:23:12.205411+00
4c1ec12b-6403-41c9-9d60-6f334fff1edb	poll_watch	{"owner_id": "c7fc917c-2d75-4e59-b62e-cb814f870adf", "watch_rule_id": "d6f9e62e-d2fe-434c-9303-c691a3dd3fb9"}	done	2026-08-26 03:45:11.297242+00	0	5	\N	\N	2026-08-26 03:45:11.291633+00	2026-08-26 03:45:12.430269+00
\.


--
-- Data for Name: normalization_runs; Type: TABLE DATA; Schema: public; Owner: library
--

COPY public.normalization_runs (id, owner_id, input_asset_id, derivative_asset_id, input_sha256, output_sha256, profile, profile_version, normalizer_version, state, needs_review, review_reason, actions, manifest, error, created_at, completed_at) FROM stdin;
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: library
--

COPY public.notifications (id, owner_id, kind, title, body, data, read_at, created_at) FROM stdin;
\.


--
-- Data for Name: outbox_events; Type: TABLE DATA; Schema: public; Owner: library
--

COPY public.outbox_events (id, event_type, payload, status, attempts, last_error, created_at, processed_at) FROM stdin;
9835dee5-2a52-42af-a1d7-629fdcba766e	BookFileImported	{"work_id": "c87fd61d-4c55-4124-8493-2988aed4972b", "asset_id": "f3bd8666-0534-4f03-b32e-e305d55e145d", "filename": "Киз — Классика 01 — Цветы для Элджернона.fb2", "owner_id": "d068a75e-f341-4daa-9243-168a011d616f"}	pending	0	\N	2026-08-25 10:16:35.577283+00	\N
968846ac-f6b5-4b26-b89c-df119fa82ce6	WorkMatched	{"work_id": "c87fd61d-4c55-4124-8493-2988aed4972b", "asset_id": "f3bd8666-0534-4f03-b32e-e305d55e145d", "evidence": {"parsed": {"title": "Цветы для Элджернона", "author": "Киз", "series": "Классика", "series_index": "01"}, "parser": "deterministic-v1", "work_id": "c87fd61d-4c55-4124-8493-2988aed4972b", "decision": "auto_applied_well_formed_filename"}, "owner_id": "d068a75e-f341-4daa-9243-168a011d616f"}	pending	0	\N	2026-08-25 10:16:35.603007+00	\N
fac9e39c-6e9a-4ee9-af2f-a2cff802e88d	NormalizationCompleted	{"run_id": "6f204057-d25e-4890-a264-68d22a5d201b", "owner_id": "d068a75e-f341-4daa-9243-168a011d616f", "input_asset_id": "f3bd8666-0534-4f03-b32e-e305d55e145d", "derivative_asset_id": "19078917-3d92-4a30-a71a-ecae57d8297a"}	pending	0	\N	2026-08-25 10:23:12.176279+00	\N
19a75d67-9ee2-4181-85a7-47c4da4997d4	NormalizationCompleted	{"run_id": "6f204057-d25e-4890-a264-68d22a5d201b", "owner_id": "d068a75e-f341-4daa-9243-168a011d616f", "preferred_asset_id": "19078917-3d92-4a30-a71a-ecae57d8297a"}	pending	0	\N	2026-08-25 10:23:46.772326+00	\N
a7720286-45e9-473f-9fc7-01070cc3e716	BookFileImported	{"work_id": null, "asset_id": "6e84c2d6-e1ea-4eac-9dcf-a5a2132d1983", "filename": "непонятный файл.fb2", "owner_id": "de3d4da8-6051-4c0b-b437-e5ae9b35e93d"}	pending	0	\N	2026-08-25 11:29:11.306081+00	\N
5905bef8-3062-439c-9c8a-0dee69bb9f11	BookFileImported	{"work_id": "c13c8982-6238-4e71-a5f5-08f5cb657d31", "asset_id": "5432e492-f830-4914-914c-158345a5f7a9", "filename": "Лукьяненко — Черновик 01 — Черновик том 01.fb2", "owner_id": "b9d45698-922a-4740-be56-b06a06a40cc0"}	pending	0	\N	2026-08-26 02:01:51.046857+00	\N
25855e0c-7b95-46c3-ba65-27090f974cd3	WorkMatched	{"work_id": "c13c8982-6238-4e71-a5f5-08f5cb657d31", "asset_id": "5432e492-f830-4914-914c-158345a5f7a9", "evidence": {"parsed": {"title": "Черновик том 01", "author": "Лукьяненко", "series": "Черновик", "series_index": "01"}, "parser": "deterministic-v1", "work_id": "c13c8982-6238-4e71-a5f5-08f5cb657d31", "decision": "auto_applied_well_formed_filename"}, "owner_id": "b9d45698-922a-4740-be56-b06a06a40cc0"}	pending	0	\N	2026-08-26 02:01:51.062935+00	\N
4badc6c7-4740-4185-a141-d16e784fc233	BookFileImported	{"work_id": "4891ac89-2143-4f8c-a515-f4ea096cc431", "asset_id": "a37a9a40-ea3c-4523-b73b-db111c0d73d7", "filename": "Лукьяненко — Черновик 02 — Черновик том 02.fb2", "owner_id": "b9d45698-922a-4740-be56-b06a06a40cc0"}	pending	0	\N	2026-08-26 02:01:51.26072+00	\N
23f41a17-c96f-48a3-a756-df6698774e8d	WorkMatched	{"work_id": "4891ac89-2143-4f8c-a515-f4ea096cc431", "asset_id": "a37a9a40-ea3c-4523-b73b-db111c0d73d7", "evidence": {"parsed": {"title": "Черновик том 02", "author": "Лукьяненко", "series": "Черновик", "series_index": "02"}, "parser": "deterministic-v1", "work_id": "4891ac89-2143-4f8c-a515-f4ea096cc431", "decision": "auto_applied_well_formed_filename"}, "owner_id": "b9d45698-922a-4740-be56-b06a06a40cc0"}	pending	0	\N	2026-08-26 02:01:51.270645+00	\N
c3423fc6-965d-4965-a101-45962438e341	BookFileImported	{"work_id": "f690f865-b67f-496c-a3e7-ff6d491bf094", "asset_id": "4d8f90a5-47fb-47b1-b0c1-cdb93bb22c16", "filename": "Лукьяненко — Черновик 03 — Черновик том 03.fb2", "owner_id": "b9d45698-922a-4740-be56-b06a06a40cc0"}	pending	0	\N	2026-08-26 02:01:51.434377+00	\N
6e7a2db6-df1c-45bf-9eaa-5f5302ded9df	WorkMatched	{"work_id": "f690f865-b67f-496c-a3e7-ff6d491bf094", "asset_id": "4d8f90a5-47fb-47b1-b0c1-cdb93bb22c16", "evidence": {"parsed": {"title": "Черновик том 03", "author": "Лукьяненко", "series": "Черновик", "series_index": "03"}, "parser": "deterministic-v1", "work_id": "f690f865-b67f-496c-a3e7-ff6d491bf094", "decision": "auto_applied_well_formed_filename"}, "owner_id": "b9d45698-922a-4740-be56-b06a06a40cc0"}	pending	0	\N	2026-08-26 02:01:51.453156+00	\N
6b920e26-9e22-4d19-9760-97cfcb4cb2fb	BookMarkedRead	{"status": "read", "work_id": "c13c8982-6238-4e71-a5f5-08f5cb657d31", "owner_id": "b9d45698-922a-4740-be56-b06a06a40cc0"}	pending	0	\N	2026-08-26 02:03:14.485488+00	\N
3533e671-94d9-4c4c-b985-4a821da987ed	BookFileImported	{"work_id": "44f95a5f-a4e3-4f99-905f-4a8384acda19", "asset_id": "4ec0bf5f-fc87-48e8-914f-e4d9683f132b", "filename": "Киз — Классика 01 — Цветы для Элджернона.fb2", "owner_id": "8bdd4649-2968-4d95-bf96-f1748f8ec39b"}	pending	0	\N	2026-08-26 04:38:39.679495+00	\N
a06332fc-76eb-41f7-98a6-6daf9eb00bba	WorkMatched	{"work_id": "44f95a5f-a4e3-4f99-905f-4a8384acda19", "asset_id": "4ec0bf5f-fc87-48e8-914f-e4d9683f132b", "evidence": {"parsed": {"title": "Цветы для Элджернона", "author": "Киз", "series": "Классика", "series_index": "01"}, "parser": "deterministic-v1", "work_id": "44f95a5f-a4e3-4f99-905f-4a8384acda19", "decision": "auto_applied_well_formed_filename"}, "owner_id": "8bdd4649-2968-4d95-bf96-f1748f8ec39b"}	pending	0	\N	2026-08-26 04:38:39.697868+00	\N
51ab4a3e-22de-4c62-affe-5ca4d2459572	BookFileImported	{"work_id": null, "asset_id": "71188d34-fa3b-4a66-b5eb-8c573960ca00", "filename": "Соболева_Л_А_Артель_Света_3824_1.fb2", "owner_id": "68ace0b5-3f85-4d88-8460-65ad4bee6826"}	pending	0	\N	2026-08-26 08:51:30.853762+00	\N
\.


--
-- Data for Name: reading_state_history; Type: TABLE DATA; Schema: public; Owner: library
--

COPY public.reading_state_history (id, owner_id, work_id, from_status, to_status, source, changed_at) FROM stdin;
\.


--
-- Data for Name: reading_states; Type: TABLE DATA; Schema: public; Owner: library
--

COPY public.reading_states (id, owner_id, work_id, status, progress_percent, change_source, changed_at, created_at) FROM stdin;
\.


--
-- Data for Name: series; Type: TABLE DATA; Schema: public; Owner: library
--

COPY public.series (id, owner_id, title, title_normalized, description, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: series_aliases; Type: TABLE DATA; Schema: public; Owner: library
--

COPY public.series_aliases (id, owner_id, series_id, alias, alias_normalized) FROM stdin;
\.


--
-- Data for Name: series_memberships; Type: TABLE DATA; Schema: public; Owner: library
--

COPY public.series_memberships (id, owner_id, series_id, work_id, index_raw, index_sort, membership_type) FROM stdin;
\.


--
-- Data for Name: series_user_states; Type: TABLE DATA; Schema: public; Owner: library
--

COPY public.series_user_states (id, owner_id, series_id, status_override, note, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: source_author_records; Type: TABLE DATA; Schema: public; Owner: library
--

COPY public.source_author_records (id, owner_id, adapter_id, external_id, author_id, url, raw_metadata, last_observed_at, created_at) FROM stdin;
\.


--
-- Data for Name: source_observations; Type: TABLE DATA; Schema: public; Owner: library
--

COPY public.source_observations (id, owner_id, watch_rule_id, adapter_id, external_id, title, author_name, url, parser_version, raw, observed_at) FROM stdin;
\.


--
-- Data for Name: source_records; Type: TABLE DATA; Schema: public; Owner: library
--

COPY public.source_records (id, owner_id, adapter_id, external_id, work_id, url, raw_metadata, parser_version, last_observed_at, created_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: library
--

COPY public.users (id, email, password_hash, display_name, is_active, is_superuser, created_at, updated_at) FROM stdin;
68ace0b5-3f85-4d88-8460-65ad4bee6826	roman@gorbunovr.ru	$argon2id$v=19$m=65536,t=3,p=4$QXscx1b/VMDBV5eVbH2PPQ$Q+14w2ZDGzPcIXZnhB23FUpoCAS6P2Ib485O8TMlweA	roman	t	t	2026-08-26 08:51:30.041994+00	2026-08-26 08:51:30.042004+00
\.


--
-- Data for Name: watch_rules; Type: TABLE DATA; Schema: public; Owner: library
--

COPY public.watch_rules (id, owner_id, adapter_id, name, url, interval_seconds, enabled, etag, last_modified, last_polled_at, next_poll_at, failure_count, degraded, last_error, created_at) FROM stdin;
\.


--
-- Data for Name: work_authors; Type: TABLE DATA; Schema: public; Owner: library
--

COPY public.work_authors (id, owner_id, work_id, author_id, role, "position") FROM stdin;
\.


--
-- Data for Name: works; Type: TABLE DATA; Schema: public; Owner: library
--

COPY public.works (id, owner_id, title, title_normalized, language, description, created_at, updated_at) FROM stdin;
\.


--
-- Name: ai_corrections ai_corrections_pkey; Type: CONSTRAINT; Schema: public; Owner: library
--

ALTER TABLE ONLY public.ai_corrections
    ADD CONSTRAINT ai_corrections_pkey PRIMARY KEY (id);


--
-- Name: ai_proposals ai_proposals_pkey; Type: CONSTRAINT; Schema: public; Owner: library
--

ALTER TABLE ONLY public.ai_proposals
    ADD CONSTRAINT ai_proposals_pkey PRIMARY KEY (id);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: library
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: api_tokens api_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: library
--

ALTER TABLE ONLY public.api_tokens
    ADD CONSTRAINT api_tokens_pkey PRIMARY KEY (id);


--
-- Name: asset_relations asset_relations_pkey; Type: CONSTRAINT; Schema: public; Owner: library
--

ALTER TABLE ONLY public.asset_relations
    ADD CONSTRAINT asset_relations_pkey PRIMARY KEY (id);


--
-- Name: assets assets_pkey; Type: CONSTRAINT; Schema: public; Owner: library
--

ALTER TABLE ONLY public.assets
    ADD CONSTRAINT assets_pkey PRIMARY KEY (id);


--
-- Name: audit_log audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: library
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_pkey PRIMARY KEY (id);


--
-- Name: author_aliases author_aliases_pkey; Type: CONSTRAINT; Schema: public; Owner: library
--

ALTER TABLE ONLY public.author_aliases
    ADD CONSTRAINT author_aliases_pkey PRIMARY KEY (id);


--
-- Name: authors authors_pkey; Type: CONSTRAINT; Schema: public; Owner: library
--

ALTER TABLE ONLY public.authors
    ADD CONSTRAINT authors_pkey PRIMARY KEY (id);


--
-- Name: duplicate_candidates duplicate_candidates_pkey; Type: CONSTRAINT; Schema: public; Owner: library
--

ALTER TABLE ONLY public.duplicate_candidates
    ADD CONSTRAINT duplicate_candidates_pkey PRIMARY KEY (id);


--
-- Name: import_batches import_batches_pkey; Type: CONSTRAINT; Schema: public; Owner: library
--

ALTER TABLE ONLY public.import_batches
    ADD CONSTRAINT import_batches_pkey PRIMARY KEY (id);


--
-- Name: import_items import_items_pkey; Type: CONSTRAINT; Schema: public; Owner: library
--

ALTER TABLE ONLY public.import_items
    ADD CONSTRAINT import_items_pkey PRIMARY KEY (id);


--
-- Name: jobs jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: library
--

ALTER TABLE ONLY public.jobs
    ADD CONSTRAINT jobs_pkey PRIMARY KEY (id);


--
-- Name: normalization_runs normalization_runs_pkey; Type: CONSTRAINT; Schema: public; Owner: library
--

ALTER TABLE ONLY public.normalization_runs
    ADD CONSTRAINT normalization_runs_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: library
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: outbox_events outbox_events_pkey; Type: CONSTRAINT; Schema: public; Owner: library
--

ALTER TABLE ONLY public.outbox_events
    ADD CONSTRAINT outbox_events_pkey PRIMARY KEY (id);


--
-- Name: reading_state_history reading_state_history_pkey; Type: CONSTRAINT; Schema: public; Owner: library
--

ALTER TABLE ONLY public.reading_state_history
    ADD CONSTRAINT reading_state_history_pkey PRIMARY KEY (id);


--
-- Name: reading_states reading_states_pkey; Type: CONSTRAINT; Schema: public; Owner: library
--

ALTER TABLE ONLY public.reading_states
    ADD CONSTRAINT reading_states_pkey PRIMARY KEY (id);


--
-- Name: series_aliases series_aliases_pkey; Type: CONSTRAINT; Schema: public; Owner: library
--

ALTER TABLE ONLY public.series_aliases
    ADD CONSTRAINT series_aliases_pkey PRIMARY KEY (id);


--
-- Name: series_memberships series_memberships_pkey; Type: CONSTRAINT; Schema: public; Owner: library
--

ALTER TABLE ONLY public.series_memberships
    ADD CONSTRAINT series_memberships_pkey PRIMARY KEY (id);


--
-- Name: series series_pkey; Type: CONSTRAINT; Schema: public; Owner: library
--

ALTER TABLE ONLY public.series
    ADD CONSTRAINT series_pkey PRIMARY KEY (id);


--
-- Name: series_user_states series_user_states_pkey; Type: CONSTRAINT; Schema: public; Owner: library
--

ALTER TABLE ONLY public.series_user_states
    ADD CONSTRAINT series_user_states_pkey PRIMARY KEY (id);


--
-- Name: source_author_records source_author_records_pkey; Type: CONSTRAINT; Schema: public; Owner: library
--

ALTER TABLE ONLY public.source_author_records
    ADD CONSTRAINT source_author_records_pkey PRIMARY KEY (id);


--
-- Name: source_observations source_observations_pkey; Type: CONSTRAINT; Schema: public; Owner: library
--

ALTER TABLE ONLY public.source_observations
    ADD CONSTRAINT source_observations_pkey PRIMARY KEY (id);


--
-- Name: source_records source_records_pkey; Type: CONSTRAINT; Schema: public; Owner: library
--

ALTER TABLE ONLY public.source_records
    ADD CONSTRAINT source_records_pkey PRIMARY KEY (id);


--
-- Name: asset_relations uq_asset_relations; Type: CONSTRAINT; Schema: public; Owner: library
--

ALTER TABLE ONLY public.asset_relations
    ADD CONSTRAINT uq_asset_relations UNIQUE (asset_id, related_asset_id, relation_type);


--
-- Name: assets uq_assets_owner_sha256; Type: CONSTRAINT; Schema: public; Owner: library
--

ALTER TABLE ONLY public.assets
    ADD CONSTRAINT uq_assets_owner_sha256 UNIQUE (owner_id, sha256);


--
-- Name: author_aliases uq_author_aliases_owner_alias; Type: CONSTRAINT; Schema: public; Owner: library
--

ALTER TABLE ONLY public.author_aliases
    ADD CONSTRAINT uq_author_aliases_owner_alias UNIQUE (owner_id, alias_normalized);


--
-- Name: authors uq_authors_owner_name; Type: CONSTRAINT; Schema: public; Owner: library
--

ALTER TABLE ONLY public.authors
    ADD CONSTRAINT uq_authors_owner_name UNIQUE (owner_id, name_normalized);


--
-- Name: source_observations uq_observations_rule_external; Type: CONSTRAINT; Schema: public; Owner: library
--

ALTER TABLE ONLY public.source_observations
    ADD CONSTRAINT uq_observations_rule_external UNIQUE (watch_rule_id, external_id);


--
-- Name: reading_states uq_reading_states_owner_work; Type: CONSTRAINT; Schema: public; Owner: library
--

ALTER TABLE ONLY public.reading_states
    ADD CONSTRAINT uq_reading_states_owner_work UNIQUE (owner_id, work_id);


--
-- Name: series_aliases uq_series_aliases_owner_alias; Type: CONSTRAINT; Schema: public; Owner: library
--

ALTER TABLE ONLY public.series_aliases
    ADD CONSTRAINT uq_series_aliases_owner_alias UNIQUE (owner_id, alias_normalized);


--
-- Name: series_memberships uq_series_memberships; Type: CONSTRAINT; Schema: public; Owner: library
--

ALTER TABLE ONLY public.series_memberships
    ADD CONSTRAINT uq_series_memberships UNIQUE (series_id, work_id);


--
-- Name: series uq_series_owner_title; Type: CONSTRAINT; Schema: public; Owner: library
--

ALTER TABLE ONLY public.series
    ADD CONSTRAINT uq_series_owner_title UNIQUE (owner_id, title_normalized);


--
-- Name: source_author_records uq_source_author_records_uniq; Type: CONSTRAINT; Schema: public; Owner: library
--

ALTER TABLE ONLY public.source_author_records
    ADD CONSTRAINT uq_source_author_records_uniq UNIQUE (adapter_id, external_id);


--
-- Name: source_records uq_source_records_adapter_external; Type: CONSTRAINT; Schema: public; Owner: library
--

ALTER TABLE ONLY public.source_records
    ADD CONSTRAINT uq_source_records_adapter_external UNIQUE (adapter_id, external_id);


--
-- Name: work_authors uq_work_authors; Type: CONSTRAINT; Schema: public; Owner: library
--

ALTER TABLE ONLY public.work_authors
    ADD CONSTRAINT uq_work_authors UNIQUE (work_id, author_id, role);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: library
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: watch_rules watch_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: library
--

ALTER TABLE ONLY public.watch_rules
    ADD CONSTRAINT watch_rules_pkey PRIMARY KEY (id);


--
-- Name: work_authors work_authors_pkey; Type: CONSTRAINT; Schema: public; Owner: library
--

ALTER TABLE ONLY public.work_authors
    ADD CONSTRAINT work_authors_pkey PRIMARY KEY (id);


--
-- Name: works works_pkey; Type: CONSTRAINT; Schema: public; Owner: library
--

ALTER TABLE ONLY public.works
    ADD CONSTRAINT works_pkey PRIMARY KEY (id);


--
-- Name: ix_ai_corrections_owner_created; Type: INDEX; Schema: public; Owner: library
--

CREATE INDEX ix_ai_corrections_owner_created ON public.ai_corrections USING btree (owner_id, created_at);


--
-- Name: ix_api_tokens_user; Type: INDEX; Schema: public; Owner: library
--

CREATE INDEX ix_api_tokens_user ON public.api_tokens USING btree (user_id);


--
-- Name: ix_assets_sha256; Type: INDEX; Schema: public; Owner: library
--

CREATE INDEX ix_assets_sha256 ON public.assets USING btree (sha256);


--
-- Name: ix_assets_work; Type: INDEX; Schema: public; Owner: library
--

CREATE INDEX ix_assets_work ON public.assets USING btree (work_id);


--
-- Name: ix_audit_log_action_time; Type: INDEX; Schema: public; Owner: library
--

CREATE INDEX ix_audit_log_action_time ON public.audit_log USING btree (action, created_at);


--
-- Name: ix_audit_log_user_time; Type: INDEX; Schema: public; Owner: library
--

CREATE INDEX ix_audit_log_user_time ON public.audit_log USING btree (user_id, created_at);


--
-- Name: ix_authors_owner; Type: INDEX; Schema: public; Owner: library
--

CREATE INDEX ix_authors_owner ON public.authors USING btree (owner_id);


--
-- Name: ix_duplicate_candidates_owner_status; Type: INDEX; Schema: public; Owner: library
--

CREATE INDEX ix_duplicate_candidates_owner_status ON public.duplicate_candidates USING btree (owner_id, status);


--
-- Name: ix_import_batches_owner_created; Type: INDEX; Schema: public; Owner: library
--

CREATE INDEX ix_import_batches_owner_created ON public.import_batches USING btree (owner_id, created_at);


--
-- Name: ix_import_items_batch; Type: INDEX; Schema: public; Owner: library
--

CREATE INDEX ix_import_items_batch ON public.import_items USING btree (batch_id);


--
-- Name: ix_import_items_owner_status; Type: INDEX; Schema: public; Owner: library
--

CREATE INDEX ix_import_items_owner_status ON public.import_items USING btree (owner_id, status);


--
-- Name: ix_jobs_status_run_at; Type: INDEX; Schema: public; Owner: library
--

CREATE INDEX ix_jobs_status_run_at ON public.jobs USING btree (status, run_at);


--
-- Name: ix_normalization_runs_input; Type: INDEX; Schema: public; Owner: library
--

CREATE INDEX ix_normalization_runs_input ON public.normalization_runs USING btree (input_asset_id);


--
-- Name: ix_normalization_runs_owner_created; Type: INDEX; Schema: public; Owner: library
--

CREATE INDEX ix_normalization_runs_owner_created ON public.normalization_runs USING btree (owner_id, created_at);


--
-- Name: ix_notifications_owner_created; Type: INDEX; Schema: public; Owner: library
--

CREATE INDEX ix_notifications_owner_created ON public.notifications USING btree (owner_id, created_at);


--
-- Name: ix_notifications_unread; Type: INDEX; Schema: public; Owner: library
--

CREATE INDEX ix_notifications_unread ON public.notifications USING btree (owner_id, read_at);


--
-- Name: ix_observations_owner_seen; Type: INDEX; Schema: public; Owner: library
--

CREATE INDEX ix_observations_owner_seen ON public.source_observations USING btree (owner_id, observed_at);


--
-- Name: ix_outbox_events_status_created; Type: INDEX; Schema: public; Owner: library
--

CREATE INDEX ix_outbox_events_status_created ON public.outbox_events USING btree (status, created_at);


--
-- Name: ix_reading_history_owner_work; Type: INDEX; Schema: public; Owner: library
--

CREATE INDEX ix_reading_history_owner_work ON public.reading_state_history USING btree (owner_id, work_id, changed_at);


--
-- Name: ix_series_memberships_sort; Type: INDEX; Schema: public; Owner: library
--

CREATE INDEX ix_series_memberships_sort ON public.series_memberships USING btree (series_id, index_sort);


--
-- Name: ix_source_records_work; Type: INDEX; Schema: public; Owner: library
--

CREATE INDEX ix_source_records_work ON public.source_records USING btree (work_id);


--
-- Name: ix_watch_rules_due; Type: INDEX; Schema: public; Owner: library
--

CREATE INDEX ix_watch_rules_due ON public.watch_rules USING btree (enabled, next_poll_at);


--
-- Name: ix_watch_rules_owner; Type: INDEX; Schema: public; Owner: library
--

CREATE INDEX ix_watch_rules_owner ON public.watch_rules USING btree (owner_id);


--
-- Name: ix_works_owner_title; Type: INDEX; Schema: public; Owner: library
--

CREATE INDEX ix_works_owner_title ON public.works USING btree (owner_id, title_normalized);


--
-- Name: uq_ai_proposals_cache; Type: INDEX; Schema: public; Owner: library
--

CREATE UNIQUE INDEX uq_ai_proposals_cache ON public.ai_proposals USING btree (digest_hash, model, prompt_version, schema_version);


--
-- Name: uq_api_tokens_hash; Type: INDEX; Schema: public; Owner: library
--

CREATE UNIQUE INDEX uq_api_tokens_hash ON public.api_tokens USING btree (token_hash);


--
-- Name: uq_normalization_runs_idempotent; Type: INDEX; Schema: public; Owner: library
--

CREATE UNIQUE INDEX uq_normalization_runs_idempotent ON public.normalization_runs USING btree (input_asset_id, profile, profile_version, normalizer_version) WHERE ((state)::text <> ALL ((ARRAY['failed'::character varying, 'needs_review'::character varying])::text[]));


--
-- Name: uq_series_user_states; Type: INDEX; Schema: public; Owner: library
--

CREATE UNIQUE INDEX uq_series_user_states ON public.series_user_states USING btree (owner_id, series_id);


--
-- Name: uq_users_email; Type: INDEX; Schema: public; Owner: library
--

CREATE UNIQUE INDEX uq_users_email ON public.users USING btree (email);


--
-- Name: ai_corrections ai_corrections_import_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: library
--

ALTER TABLE ONLY public.ai_corrections
    ADD CONSTRAINT ai_corrections_import_item_id_fkey FOREIGN KEY (import_item_id) REFERENCES public.import_items(id) ON DELETE SET NULL;


--
-- Name: ai_corrections ai_corrections_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: library
--

ALTER TABLE ONLY public.ai_corrections
    ADD CONSTRAINT ai_corrections_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: api_tokens api_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: library
--

ALTER TABLE ONLY public.api_tokens
    ADD CONSTRAINT api_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: asset_relations asset_relations_asset_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: library
--

ALTER TABLE ONLY public.asset_relations
    ADD CONSTRAINT asset_relations_asset_id_fkey FOREIGN KEY (asset_id) REFERENCES public.assets(id) ON DELETE CASCADE;


--
-- Name: asset_relations asset_relations_related_asset_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: library
--

ALTER TABLE ONLY public.asset_relations
    ADD CONSTRAINT asset_relations_related_asset_id_fkey FOREIGN KEY (related_asset_id) REFERENCES public.assets(id) ON DELETE CASCADE;


--
-- Name: audit_log audit_log_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: library
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: author_aliases author_aliases_author_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: library
--

ALTER TABLE ONLY public.author_aliases
    ADD CONSTRAINT author_aliases_author_id_fkey FOREIGN KEY (author_id) REFERENCES public.authors(id) ON DELETE CASCADE;


--
-- Name: duplicate_candidates duplicate_candidates_asset_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: library
--

ALTER TABLE ONLY public.duplicate_candidates
    ADD CONSTRAINT duplicate_candidates_asset_id_fkey FOREIGN KEY (asset_id) REFERENCES public.assets(id) ON DELETE CASCADE;


--
-- Name: duplicate_candidates duplicate_candidates_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: library
--

ALTER TABLE ONLY public.duplicate_candidates
    ADD CONSTRAINT duplicate_candidates_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: duplicate_candidates duplicate_candidates_suspected_of_asset_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: library
--

ALTER TABLE ONLY public.duplicate_candidates
    ADD CONSTRAINT duplicate_candidates_suspected_of_asset_id_fkey FOREIGN KEY (suspected_of_asset_id) REFERENCES public.assets(id) ON DELETE CASCADE;


--
-- Name: asset_relations fk_asset_relations_owner_users; Type: FK CONSTRAINT; Schema: public; Owner: library
--

ALTER TABLE ONLY public.asset_relations
    ADD CONSTRAINT fk_asset_relations_owner_users FOREIGN KEY (owner_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: assets fk_assets_owner_users; Type: FK CONSTRAINT; Schema: public; Owner: library
--

ALTER TABLE ONLY public.assets
    ADD CONSTRAINT fk_assets_owner_users FOREIGN KEY (owner_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: assets fk_assets_work; Type: FK CONSTRAINT; Schema: public; Owner: library
--

ALTER TABLE ONLY public.assets
    ADD CONSTRAINT fk_assets_work FOREIGN KEY (work_id) REFERENCES public.works(id) ON DELETE SET NULL;


--
-- Name: author_aliases fk_author_aliases_owner_users; Type: FK CONSTRAINT; Schema: public; Owner: library
--

ALTER TABLE ONLY public.author_aliases
    ADD CONSTRAINT fk_author_aliases_owner_users FOREIGN KEY (owner_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: authors fk_authors_owner_users; Type: FK CONSTRAINT; Schema: public; Owner: library
--

ALTER TABLE ONLY public.authors
    ADD CONSTRAINT fk_authors_owner_users FOREIGN KEY (owner_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: reading_states fk_reading_states_owner_users; Type: FK CONSTRAINT; Schema: public; Owner: library
--

ALTER TABLE ONLY public.reading_states
    ADD CONSTRAINT fk_reading_states_owner_users FOREIGN KEY (owner_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: series_aliases fk_series_aliases_owner_users; Type: FK CONSTRAINT; Schema: public; Owner: library
--

ALTER TABLE ONLY public.series_aliases
    ADD CONSTRAINT fk_series_aliases_owner_users FOREIGN KEY (owner_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: series_memberships fk_series_memberships_owner_users; Type: FK CONSTRAINT; Schema: public; Owner: library
--

ALTER TABLE ONLY public.series_memberships
    ADD CONSTRAINT fk_series_memberships_owner_users FOREIGN KEY (owner_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: series fk_series_owner_users; Type: FK CONSTRAINT; Schema: public; Owner: library
--

ALTER TABLE ONLY public.series
    ADD CONSTRAINT fk_series_owner_users FOREIGN KEY (owner_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: source_author_records fk_source_author_records_owner_users; Type: FK CONSTRAINT; Schema: public; Owner: library
--

ALTER TABLE ONLY public.source_author_records
    ADD CONSTRAINT fk_source_author_records_owner_users FOREIGN KEY (owner_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: source_records fk_source_records_owner_users; Type: FK CONSTRAINT; Schema: public; Owner: library
--

ALTER TABLE ONLY public.source_records
    ADD CONSTRAINT fk_source_records_owner_users FOREIGN KEY (owner_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: work_authors fk_work_authors_owner_users; Type: FK CONSTRAINT; Schema: public; Owner: library
--

ALTER TABLE ONLY public.work_authors
    ADD CONSTRAINT fk_work_authors_owner_users FOREIGN KEY (owner_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: works fk_works_owner_users; Type: FK CONSTRAINT; Schema: public; Owner: library
--

ALTER TABLE ONLY public.works
    ADD CONSTRAINT fk_works_owner_users FOREIGN KEY (owner_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: import_batches import_batches_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: library
--

ALTER TABLE ONLY public.import_batches
    ADD CONSTRAINT import_batches_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: import_items import_items_asset_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: library
--

ALTER TABLE ONLY public.import_items
    ADD CONSTRAINT import_items_asset_id_fkey FOREIGN KEY (asset_id) REFERENCES public.assets(id) ON DELETE SET NULL;


--
-- Name: import_items import_items_batch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: library
--

ALTER TABLE ONLY public.import_items
    ADD CONSTRAINT import_items_batch_id_fkey FOREIGN KEY (batch_id) REFERENCES public.import_batches(id) ON DELETE CASCADE;


--
-- Name: import_items import_items_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: library
--

ALTER TABLE ONLY public.import_items
    ADD CONSTRAINT import_items_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: import_items import_items_work_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: library
--

ALTER TABLE ONLY public.import_items
    ADD CONSTRAINT import_items_work_id_fkey FOREIGN KEY (work_id) REFERENCES public.works(id) ON DELETE SET NULL;


--
-- Name: normalization_runs normalization_runs_derivative_asset_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: library
--

ALTER TABLE ONLY public.normalization_runs
    ADD CONSTRAINT normalization_runs_derivative_asset_id_fkey FOREIGN KEY (derivative_asset_id) REFERENCES public.assets(id) ON DELETE SET NULL;


--
-- Name: normalization_runs normalization_runs_input_asset_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: library
--

ALTER TABLE ONLY public.normalization_runs
    ADD CONSTRAINT normalization_runs_input_asset_id_fkey FOREIGN KEY (input_asset_id) REFERENCES public.assets(id) ON DELETE CASCADE;


--
-- Name: normalization_runs normalization_runs_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: library
--

ALTER TABLE ONLY public.normalization_runs
    ADD CONSTRAINT normalization_runs_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: notifications notifications_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: library
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: reading_state_history reading_state_history_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: library
--

ALTER TABLE ONLY public.reading_state_history
    ADD CONSTRAINT reading_state_history_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: reading_state_history reading_state_history_work_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: library
--

ALTER TABLE ONLY public.reading_state_history
    ADD CONSTRAINT reading_state_history_work_id_fkey FOREIGN KEY (work_id) REFERENCES public.works(id) ON DELETE CASCADE;


--
-- Name: reading_states reading_states_work_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: library
--

ALTER TABLE ONLY public.reading_states
    ADD CONSTRAINT reading_states_work_id_fkey FOREIGN KEY (work_id) REFERENCES public.works(id) ON DELETE CASCADE;


--
-- Name: series_aliases series_aliases_series_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: library
--

ALTER TABLE ONLY public.series_aliases
    ADD CONSTRAINT series_aliases_series_id_fkey FOREIGN KEY (series_id) REFERENCES public.series(id) ON DELETE CASCADE;


--
-- Name: series_memberships series_memberships_series_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: library
--

ALTER TABLE ONLY public.series_memberships
    ADD CONSTRAINT series_memberships_series_id_fkey FOREIGN KEY (series_id) REFERENCES public.series(id) ON DELETE CASCADE;


--
-- Name: series_memberships series_memberships_work_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: library
--

ALTER TABLE ONLY public.series_memberships
    ADD CONSTRAINT series_memberships_work_id_fkey FOREIGN KEY (work_id) REFERENCES public.works(id) ON DELETE CASCADE;


--
-- Name: series_user_states series_user_states_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: library
--

ALTER TABLE ONLY public.series_user_states
    ADD CONSTRAINT series_user_states_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: series_user_states series_user_states_series_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: library
--

ALTER TABLE ONLY public.series_user_states
    ADD CONSTRAINT series_user_states_series_id_fkey FOREIGN KEY (series_id) REFERENCES public.series(id) ON DELETE CASCADE;


--
-- Name: source_author_records source_author_records_author_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: library
--

ALTER TABLE ONLY public.source_author_records
    ADD CONSTRAINT source_author_records_author_id_fkey FOREIGN KEY (author_id) REFERENCES public.authors(id) ON DELETE SET NULL;


--
-- Name: source_observations source_observations_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: library
--

ALTER TABLE ONLY public.source_observations
    ADD CONSTRAINT source_observations_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: source_observations source_observations_watch_rule_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: library
--

ALTER TABLE ONLY public.source_observations
    ADD CONSTRAINT source_observations_watch_rule_id_fkey FOREIGN KEY (watch_rule_id) REFERENCES public.watch_rules(id) ON DELETE CASCADE;


--
-- Name: source_records source_records_work_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: library
--

ALTER TABLE ONLY public.source_records
    ADD CONSTRAINT source_records_work_id_fkey FOREIGN KEY (work_id) REFERENCES public.works(id) ON DELETE SET NULL;


--
-- Name: watch_rules watch_rules_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: library
--

ALTER TABLE ONLY public.watch_rules
    ADD CONSTRAINT watch_rules_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: work_authors work_authors_author_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: library
--

ALTER TABLE ONLY public.work_authors
    ADD CONSTRAINT work_authors_author_id_fkey FOREIGN KEY (author_id) REFERENCES public.authors(id) ON DELETE RESTRICT;


--
-- Name: work_authors work_authors_work_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: library
--

ALTER TABLE ONLY public.work_authors
    ADD CONSTRAINT work_authors_work_id_fkey FOREIGN KEY (work_id) REFERENCES public.works(id) ON DELETE CASCADE;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: library
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;


--
-- PostgreSQL database dump complete
--

\unrestrict DeWnVN22ph54nweoUo1D1VlSjG6lJfZsuYbG1AIuz8SS7OLcN5Kxq7kvB0VF7lI

